/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes.model;

/**
 *
 * @author 888872
 */
public class Cacamba {
        
        private int id;
        private String tamanho;
        private double preco_unitario;
        private String descricao;
        private String disponibilidade;
        private String obs;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getTamanho() {
            return tamanho;
        }

        public void setTamanho(String tamanho) {
            this.tamanho = tamanho;
        }

        public double getPreco_unitario() {
            return preco_unitario;
        }

        public void setPreco_unitario(double preco_unitario) {
            this.preco_unitario = preco_unitario;
        }

        public String getDescricao() {
            return descricao;
        }

        public void setDescricao(String descricao) {
            this.descricao = descricao;
        }

        public String getDisponibilidade() {
            return disponibilidade;
        }

        public void setDisponibilidade(String disponibilidade) {
            this.disponibilidade = disponibilidade;
        }

        public String getObs() {
            return obs;
        }

        public void setObs(String obs) {
            this.obs = obs;
        }
        
        
    }
