/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes.model;



/**
 *
 * @author rafae
 */
public class VendaS {
    
    private int id;
    private Clientes cliente;
    private Containers container;
    private Cacamba cacamba;
    private String data_pedido;  
    private int quantidade;
    private double total_venda;

    public VendaS() {
       
        this.cliente = cliente;
        this.container = container;
        this.cacamba = cacamba;
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Clientes getCliente() {
        return cliente;
    }

    public void setCliente(Clientes cliente) {
        this.cliente = cliente;
    }

    public Containers getContainer() {
        return container;
    }

    public void setContainer(Containers container) {
        this.container = container;
    }

    public Cacamba getCacamba() {
        return cacamba;
    }

    public void setCacamba(Cacamba cacamba) {
        this.cacamba = cacamba;
    }

    public String getData_pedido() {
        return data_pedido;
    }

    public void setData_pedido(String data_pedido) {
        this.data_pedido = data_pedido;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getTotal_venda() {
        return total_venda;
    }

    public void setTotal_venda(double total_venda) {
        this.total_venda = total_venda;
    }

    
    
}
